# 快速线性回归（巡线）例程
#
# 这个例子展示了如何在OpenMV Cam上使用get_regression（）方法来获得
# ROI的线性回归。 使用这种方法，你可以轻松地建立一个机器人，它可以
# 跟踪所有指向相同的总方向但实际上没有连接的线。 在线路上使用
# find_blobs（），以便更好地过滤选项和控制。
#
# 这被称为快速线性回归，因为我们使用最小二乘法来拟合线。然而，这种方法
# 对于任何具有很多（或者甚至是任何）异常点的图像都是不好的，
# 这会破坏线条拟合.

#设置阈值，（0，100）检测黑色线
black = (0, 31, -13, 5, -11, 9) # Grayscale threshold for dark things...
red = (17, 45, 20, 49, 3, 38)
red_black = (22, 100, 12, 78, -3, 43)
linetrack_roi = (50,0,220,240)
THRESHOLD = red_black
#设置是否使用img.binary()函数进行图像分割
BINARY_VISIBLE = False # 首先执行二进制操作，以便您可以看到正在运行的线性回归...虽然可能会降低FPS。
import sensor, image, time
from pid import PID
from pyb import Pin, Timer
import fork_check
sensor.reset()  # Reset and initialize the sensor.
sensor.set_pixformat(sensor.RGB565)  # Set pixel format to RGB565 (or GRAYSCALE)
sensor.set_framesize(sensor.QVGA)  # Set frame size to QVGA (320x240)
#sensor.set_hmirror(True)
#sensor.set_vflip(True)
sensor.skip_frames(time=2000)  # Wait for settings take effect.
clock = time.clock()  # Create a clock object to track the FPS.
sensor.set_auto_gain(False)
sensor.set_auto_whitebal(False) #关闭白平衡和增益
 #pid初始化
rho_pid = PID(p=0.8, i=0)
theta_pid = PID(p=0.5, i=0)
#舵机控制初始化
tim = Timer(4, freq=100) # Frequency in Hz
ch1 = tim.channel(1, Timer.PWM, pin=Pin("P7"), pulse_width_percent=17) #12-25 右-左 17中间
pwp = 17
def rotate(angle): #(-90~90)
    if angle>90:
        angle = 90
    elif angle<-27:
        angle = -27
    pwp = 15 + 20*(angle)/180
    ch1.pulse_width_percent(round(pwp))
def qtleft():
    rotate(90)
def qtright():
    rotate(-27)
def straight():
    rotate(18)
fork_target = fork_check.check()
lastoutput = 0 #记录上以循环的输出
forkflag=0 #岔路口数字识别转弯标志位 0-巡线 1-左转 2-右转 3-开始数字识别
while(True):
    clock.tick()
    img = sensor.snapshot().binary([THRESHOLD]) if BINARY_VISIBLE else sensor.snapshot()
    fork_check.draw_rois(img)
    img.draw_rectangle(linetrack_roi,color=(0,0,0))
    if (forkflag==0): #巡线
        fork_check.findfork(fork_target,img) #分岔口检测
        if (fork_target.left_count!=0 and fork_target.right_count!=0): #判断是否有十字路口
            forkflag=1
        # 函数返回回归后的线段对象line， 有x1(), y1(), x2(), y2(), length(), theta(), rho(), magnitude()参数。
        # x1 y1 x2 y2分别代表线段的两个顶点坐标，length是线段长度，theta是线段的角度。。
        line = img.get_regression([(100,100) if BINARY_VISIBLE else THRESHOLD],roi=linetrack_roi)
        if (line):
            rho_err = (0.2*(line.x1()-img.width()/2)+0.8*(line.x2()-img.width()/2))/2 #拟合直线中心横坐标点
            if line.theta()>90:
                theta_err = line.theta()-180
            else:
                theta_err = line.theta()
            img.draw_line(line.line(), color = 127)
            print("rho_err:%f theta_err:%f"%(rho_err,theta_err))
            print(rho_err)
            if abs(theta_err)>15 or abs(rho_err)>20: #设置pid阈值防止抖动
                rho_output = rho_pid.get_pid(rho_err,1)
                theta_output = theta_pid.get_pid(theta_err,1)
                print("rho_output:%f theta_output:%f"%(rho_output,theta_output))
                output = rho_output+theta_output
                if output<0:
                    output=output*2
                elif output>0:
                    output=output*0.6
                print(abs(lastoutput-output),output)
                if abs(lastoutput-output)<10:
                    rotate(-output)
                lastoutput=output
            else:
                straight()
        else:
            straight()
    elif (forkflag==1): #左转
        qtleft()
        fork_check.findfork(fork_target,img) #分岔口检测
        if (fork_target.left_count==0 or fork_target.right_count==0): #判断转弯成功
            forkflag=0
    elif (forkflag==2): #右转
        qtright()
        fork_check.findfork(fork_target,img) #分岔口检测
        if (fork_target.left_count==0 or fork_target.right_count==0): #判断转弯成功
            forkflag=0
    elif (forkflag==3): #数字识别
        forkflag=0
    else:
        forkflag=0

    #print("FPS %f, offset = %s, theta = %s" % (clock.fps(), str((line.x1()+line.x2())/2-160) if (line) else "N/A",str(line.theta()) if (line) else "N/A"))

# About negative rho values:
# 关于负rho值:
#
# A [theta+0:-rho] tuple is the same as [theta+180:+rho].
# A [theta+0:-rho]元组与[theta+180:+rho]相同
