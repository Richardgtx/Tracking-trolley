#巡线代码
import sensor
import time
import math
from pid import PID
from pyb import UART
from pyb import LED
from time import sleep
from pyb import Pin, Timer

sensor.reset()  # Reset and initialize the sensor.
sensor.set_pixformat(sensor.RGB565)  # Set pixel format to RGB565 (or GRAYSCALE)
sensor.set_framesize(sensor.QVGA)  # Set frame size to QVGA (320x240)
sensor.set_hmirror(False)
sensor.set_vflip(False)
sensor.skip_frames(time=2000)  # Wait for settings take effect.
clock = time.clock()  # Create a clock object to track the FPS.
sensor.set_auto_gain(False)
sensor.set_auto_whitebal(False) #关闭白平衡和增益

## 绘制水平线
#def draw_hori_line(img, x0, x1, y, color):
#    for x in range(x0, x1):
#        img.set_pixel(x, y, color)
## 绘制竖直线
#def draw_vec_line(img, x, y0, y1, color):
#    for y in range(y0, y1):
#        img.set_pixel(x, y, color)
## 绘制矩形
#def draw_rect(img, x, y, w, h, color):
#    draw_hori_line(img, x, x+w, y, color)
#    draw_hori_line(img, x, x+w, y+h, color)
#    draw_vec_line(img, x, y, y+h, color)
#    draw_vec_line(img, x+w, y, y+h, color)

offset_pid = PID(p=1,i=0,d=0)

black = (0, 11, -21, 6, -23, 25) #颜色闸值
#中间一行检测点(x,y,w,h)左上角坐标
track_roi1=[(0,115,10,10),(10,115,10,10),(20,115,10,10),(30,115,10,10),(40,115,10,10),(50,115,10,10),
           (60,115,10,10),(70,115,10,10),(80,115,10,10),(90,115,10,10),(100,115,10,10),(110,115,10,10),
           (120,115,10,10),(130,115,10,10),(140,115,10,10),(150,115,10,10),(160,115,10,10),(170,115,10,10),
           (180,115,10,10),(190,115,10,10),(200,115,10,10),(210,115,10,10),(220,115,10,10),(230,115,10,10),
           (240,115,10,10),(250,115,10,10),(260,115,10,10),(270,115,10,10),(280,115,10,10),(290,115,10,10),
           (300,115,10,10),(310,115,10,10)]


class target_check(object):
    x1 = 0x00000000
    x_w = 0
    blobs_count = 0
target=target_check() # 储存检测结果


def findtrack():
    target.x1=0
    #绘制中间32个检测区域
    for rec in track_roi1:
        img.draw_rectangle(rec,color=(0,0,255))
    #检测色块
    for i in range(0,32):
        black_blobs = img.find_blobs([black],roi=track_roi1[i],merge=True,mergin=10)
        #如果识别到了黑线，hor_bits对应位置1
        for b in black_blobs:
            target.x1=target.x1|(0x01<<(31-i))
            if i<16 : target.x_w+=(1+(15-i)/5)
            target.blobs_count+=1
            if i>=16 : target.x_w-=(1+(i-16)/5)
            img.draw_circle(int(track_roi1[i][0]+track_roi1[i][2]*0.5),int(track_roi1[i][1]+track_roi1[i][3]*0.5),3,(0,255,0))

#舵机控制
tim = Timer(4, freq=100) # Frequency in Hz
ch1 = tim.channel(2, Timer.PWM, pin=Pin("P8"), pulse_width_percent=15) #5-25
pwp = 15
def rotate(angle): #(-90~90)
    pwp = 15 + 20*(angle)/180
    ch1.pulse_width_percent(round(pwp))

angle_last = 0
while True:
    clock.tick()  # Update the FPS clock.
    img = sensor.snapshot()  # Take a picture and return the image.
    target.x_w = 0
    target.blobs_count = 0
    findtrack()
    err = target.x_w/10
    print(err)
    if(err<-0.3 or err>0.3):
        if(err<-0.3 and pwp>=5):
            pid_output=offset_pid.get_pid(err,0.1)
            pwp+=pid_output
            ch1.pulse_width_percent(round(pwp))
        if(err>0.3 and pwp<=25):
            pid_output=offset_pid.get_pid(err,0.1)
            pwp+=pid_output
            ch1.pulse_width_percent(round(pwp))
    # Cauculte the offset
#    if(target.blobs_count>2):
#        err = target.x_w/15
##        print(err)
##        print(bin(target.x1))
#        # PID Cauculation
#        pid_output = offset_pid.get_pid(err,1)
#        angle = pid_output*90
#        angle_diff = angle-angle_last
#        if(pid_output>0.1 and abs(angle_diff)<60):
#            rotate(angle)
#            angle_last = pid_output*90
#        if(pid_output<-0.1 and abs(angle_diff)<60):
#            rotate(angle)
#            angle_last = angle
#        print(angle)  # Note: OpenMV Cam runs about half as fast when connected
#        print(angle_diff)
#        print("\n")
    # to the IDE. The FPS should increase once disconnected.
