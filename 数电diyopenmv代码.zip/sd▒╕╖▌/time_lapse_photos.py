# 此示例展示了如何使用OpenMV Cam拍摄延时照片，并使用RTC模块和定时器中断来实现极低功耗操作。

# 请注意，如果在相机拍照时仍然插入USB，则每次都会运行引导加载程序。
# 请从USB以外的其他设备为相机供电，以免运行引导加载程序。

import machine
import sensor
import os
from pyb import LED
import time
BLUE_LED_PIN = 3

sensor.reset()  # 初始化sensor
sensor.set_pixformat(sensor.GRAYSCALE)
sensor.set_framesize(sensor.VGA)
sensor.skip_frames(time=2000)  # 让新的设置生效。

led = LED(3) #blue
num=0
# 拍照并保存到SD卡
while (True):
    led.toggle()
    img = sensor.snapshot()
    img.save("images/" + str(num), quality=90)
    print(num)
    num=num+1
    time.sleep_ms(1000)
