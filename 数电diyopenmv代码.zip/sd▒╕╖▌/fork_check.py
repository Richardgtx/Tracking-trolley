import sensor
import time

sensor.reset()  # Reset and initialize the sensor.
sensor.set_pixformat(sensor.RGB565)  # Set pixel format to RGB565 (or GRAYSCALE)
sensor.set_framesize(sensor.QVGA)  # Set frame size to QVGA (320x240)
sensor.set_hmirror(False)
sensor.set_vflip(False)
sensor.skip_frames(time=2000)  # Wait for settings take effect.
clock = time.clock()  # Create a clock object to track the FPS.
sensor.set_auto_gain(False)
sensor.set_auto_whitebal(False) #关闭白平衡和增益


#设置阈值，（0，100）检测黑色线
THRESHOLD = (0, 31, -13, 5, -11, 9) # Grayscale threshold for dark things...

#设置是否使用img.binary()函数进行图像分割
BINARY_VISIBLE = False # 首先执行二进制操作，以便您可以看到正在运行的线性回归...虽然可能会降低FPS。
## 绘制水平线
#def draw_hori_line(img, x0, x1, y, color):
#    for x in range(x0, x1):
#        img.set_pixel(x, y, color)
## 绘制竖直线
#def draw_vec_line(img, x, y0, y1, color):
#    for y in range(y0, y1):
#        img.set_pixel(x, y, color)
## 绘制矩形
#def draw_rect(img, x, y, w, h, color):
#    draw_hori_line(img, x, x+w, y, color)
#    draw_hori_line(img, x, x+w, y+h, color)
#    draw_vec_line(img, x, y, y+h, color)
#    draw_vec_line(img, x+w, y, y+h, color)

black = (0, 11, -21, 6, -23, 25) #颜色闸值
#red = (48, 76, 21, 66, 10, 49)
red = (17, 45, 20, 49, 3, 38)
#左侧岔路识别区域
left_roi=[(0,0,10,20),(0,20,10,20),(0,40,10,20),(0,60,10,20),(0,80,10,20),(0,100,10,20),
           (0,120,10,20),(0,140,10,20),(0,160,10,20),(0,180,10,20),(0,200,10,20),(0,220,10,20)]
#右侧岔路识别区域
right_roi=[(310,0,10,20),(310,20,10,20),(310,40,10,20),(310,60,10,20),(310,80,10,20),(310,100,10,20),
           (310,120,10,20),(310,140,10,20),(310,160,10,20),(310,180,10,20),(310,200,10,20),(310,220,10,20)]


class check(object):
    left = 0x00000000
    right = 0x00000000
    left_count = 0
    right_count = 0
target=check() # 储存检测结果

def draw_rois(img):
    #绘制中间左右24个检测区域
    for rec in left_roi:
        img.draw_rectangle(rec,color=(0,0,255))
    for rec in right_roi:
        img.draw_rectangle(rec,color=(0,0,255))

def findfork(target,img):
    target.left=0
    target.right=0
    target.left_count = 0
    target.right_count = 0
    #检测色块
    for i in range(0,12): #left
        left_blobs = img.find_blobs([red],roi=left_roi[i],merge=True,mergin=10)
        #如果识别到了红色，hor_bits对应位置1
        for b in left_blobs:
            target.left=target.left|(0x01<<(11-i))
            target.left_count+=1
            img.draw_circle(int(left_roi[i][0]+left_roi[i][2]*0.5),int(left_roi[i][1]+left_roi[i][3]*0.5),3,(0,255,0))
    for i in range(0,12):
        right_blobs = img.find_blobs([red],roi=right_roi[i],merge=True,mergin=10)
        #如果识别到了红色，hor_bits对应位置1
        for b in right_blobs: #right
            target.right=target.right|(0x01<<(11-i))
            target.right_count+=1
            img.draw_circle(int(right_roi[i][0]+right_roi[i][2]*0.5),int(right_roi[i][1]+right_roi[i][3]*0.5),3,(0,255,0))

if __name__ == '__main__':
    while True:
        clock.tick()  # Update the FPS clock.
        img = sensor.snapshot()  # Take a picture and return the image.
        draw_rois(img)
        findfork()
        print("left:%s\nright:%s\nleftcount:%d\nright_count:%d\n"%(bin(target.left),bin(target.right),target.left_count,target.right_count))

        # to the IDE. The FPS should increase once disconnected.
